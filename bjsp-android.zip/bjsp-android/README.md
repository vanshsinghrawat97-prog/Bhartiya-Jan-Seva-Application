# Bhartiya Jan Seva Party – Android app

## Get the APK (no Android Studio needed)
1. Create a new GitHub repo and upload everything in this folder (including the hidden `.github` folder).
2. Open the repo's **Actions** tab. The "Build Android APK" workflow runs on every push (or press "Run workflow").
3. When it turns green (about 5 minutes), open the run and download **BJSP-app-debug-apk**, unzip it, and you get `app-debug.apk`.
4. Copy the APK to your phone and open it. Allow "Install unknown apps" when asked.

## Edit the app
All content is in `www/index.html`. Change it, push, and a new APK is built.

## Build locally instead
```
npm install && npx cap add android
npx capacitor-assets generate --android
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`
